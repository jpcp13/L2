from os import * 

fichier = open('/export/home/users1/licence/licence2/l2math2018/11608227/L2/info.tp2/Tableaux.txt', 'r')
print fichier
