
from tp1 import *

# Exercice 1

#a)

x, dx = -1.0, 0.25
X, Y, Points = [], [], [] 

while x < 2 :
     y = f(x)
     point = (x, y) 
   
     X.append(x) 
     Y.append(y) 
     Points.append(point)
     x += dx
     
print(X)
print(Y)

for point in Points:
    
    x = point[0] 
    y = point[1]
    if x >= 0.0: 
    	print('{0:10.4f} {1:10.4f}'.format(x, y)) 
 
#b)
       
import matplotlib.pyplot as plt
plt.plot(X, Y,'r') 
plt.grid()
plt.show()
#c)Voir compte rendu

