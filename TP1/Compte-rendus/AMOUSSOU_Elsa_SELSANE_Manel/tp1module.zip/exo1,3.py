
from tp1 import *


# Exercice 3

#a) voir fichier tp1.py
	
#b)

z = " Test de point fixe\n"
print(z)

 #Test1
x0 = 1.0
epsi = 10**-12

r=point_fixe(g,x0,epsi)

 #Test2
x0 = -0.6
epsi = 10**-12

r = point_fixe(g,x0,epsi)


#c)Voir compte rendu
