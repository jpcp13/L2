
from tp1 import *


# Exercice 2

#a

# Representation sur l'intervalle positif 
import numpy as np
import matplotlib.pyplot as plt
t = np.arange(1.0, 2.0, 0.01)
plt.plot(t, g(t), 'r-', t, t, 'b')
plt.grid('on')
plt.axis('equal')
plt.show()

# Representation sur l'intervalle negatif 
t = np.arange(-2.0, -0.5, 0.01)
plt.plot(t, g(t), 'r-', t, t, 'b') 
plt.grid('on')
plt.axis('equal')
plt.show()
 

#b)
#

y = " Suite xn\n"
print(y)

x0 = 1.0
xx = [x0] #Enregistre les valeurs dans une liste
for i in range(25) :
	x1 = g(x0)
	xx.append(x1)
	x0 = x1
  
print(x0)
  
print(xx)

#c)Voir compte rendu	


