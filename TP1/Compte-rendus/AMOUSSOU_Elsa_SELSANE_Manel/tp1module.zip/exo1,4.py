
from tp1 import *


# Exercice 4

#a)

a = 'Verification que les points fixe  de g sont les zero de f\n'
print(a)

epsi = 10**-12

x0 = 1.0
r = point_fixe(g,x0,epsi)

x0 = -0.6
r = point_fixe(g,x0,epsi)

#b) voir fichier tp1.py
	
#c)

#Test1
s = "Test 1 newton\n"
print(s)

x0 = 1.0
epsi = 1e-12
r = newton(f,df,x0,epsi)

#Test2
s = "Test de newton\n"
print(s)

x0 = -1.0
epsi = 1e-12
r = newton(f,df,x0,epsi)

