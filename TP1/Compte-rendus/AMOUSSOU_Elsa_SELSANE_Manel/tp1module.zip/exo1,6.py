
from tp1 import *

#Exercice 6

#a) voir fichier tp1.py

#b)
p = "Test de la dichotomie \n"
print(p)

#Test1
a = 1.5
b = 2.0
epsi = 1e-12
r = dichotomie(f,a,b,epsi)
print(r)

#Test2
a = -1.0
b = 0.0
epsi = 1e-12
r = dichotomie(f,a,b,epsi)
print(r)


	
