
from tp1 import *

#Exercice 5

#a) voir fichier tp1.py


#b)
#Test 1
print("Test de Secante 1 \n")

x0 = 1.5
x1 = 2.0
epsi=10**-12
r = secante(f,x0,x1,epsi)
print(r)

#Test 2
print("Test de Secante 2 \n")

x0 = -1.0
x1 = -0.5
epsi=10**-12
r = secante(f,x0,x1,epsi)
print(r)
