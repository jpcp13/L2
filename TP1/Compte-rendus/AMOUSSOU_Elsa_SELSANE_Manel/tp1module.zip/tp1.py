#TP1


def  f(x) : 
	return x**2 -x -1

def df(x):

	return 2*x-1.0
	
def g(x) : 
    return 1+ 1.0/x 
       
def point_fixe(g, x0, epsi):
	x=x0 
	d=2*epsi
	cpt=0
	while d>epsi :
		cpt+=1
		x1=g(x) #x1 joue le role de xn+1
		d=abs(x1-x)
		x=x1  #x joue le role de xn
		print('x vaut : {0} et compteur vaut {1}\n').format(x, cpt)
	return x

def newton(f,df,x0,epsi):
	d = 2*epsi
	x = x0
	cpt = 0
	while d > epsi and cpt < 40 :
		cpt += 1
		x1=x-f(x)/df(x)
		d = abs(x-x1)
		x = x1
		print('x vaut : {0} et compteur vaut {1}\n').format(x, cpt)
	return x1

def secante(f, x0, x1, epsi):
  	d = 2*epsi
	cpt = 0
	while d > epsi and cpt < 40 :
		cpt += 1
		num = x1-x0
		d = abs(num)
		den = f(x1)-f(x0)
		x2 = x1-num/den*f(x1)
		x0 = x1 #x0 va jouer le role de xn-1
		x1 = x2 #x1 celui de xn
		print('x vaut : {0} et compteur vaut {1}\n').format(x2, cpt)
	return x2

def dichotomie(f, a, b, epsi): 
	if b-a <= epsi:
		return a,b
	else:
		c=(a+b)/2
	if f(a)*f(c)<=0:
		return dichotomie(f,a,c,epsi)
	else:
		return dichotomie(f,c,b,epsi)	


	
	
	

