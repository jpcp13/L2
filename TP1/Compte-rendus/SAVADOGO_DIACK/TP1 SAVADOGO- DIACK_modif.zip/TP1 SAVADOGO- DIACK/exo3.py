from methods import *

def g(x):
    return 1 + 1/x



print("1er test point fixe:")
#test1 point fixe
x0 = 1.0
epsi = 1e-15
r, nbiter = point_fixe(g,x0,epsi)
print ('r = {0} et nbiter = {1}'.format(r, nbiter))
print ('g(r)={0}'.format(g(r)))

print("\n")
print("2eme test point fixe:")
#test2 point fixe
x0 = -0.6
epsi = 1e-15
r2, nbiter = point_fixe(g, x0, epsi)
print ('r2 = {0} et nbiter = {1}'.format(r2, nbiter))

