import matplotlib.pyplot as plt 

def f(x):
	return x**2 - x - 1


x, dx = -1.0, 0.1
X, Y, Points = [], [], [] 
while x <= 2:
    y = f(x)
    point = (x, y) 
    
    X.append(x) 
    Y.append(y) 
    Points.append(point)
    x += dx




plt.plot(X, Y, 'y')  ## Nous sauvegardons la figure 
plt.grid()
plt.show()
#plt.savefig('figure_1.png')

