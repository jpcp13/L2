def f(x):
	return x**2 - x - 1

from methods import *

print("dichotomie test 1:")
a = 1.5
b = 2.0
epsi = 1e-12
t, nbiter = dichotomie(f, a, b, epsi)
print ('t1 = {0} et nbiter = {1}'.format(t, nbiter))

print("\n")
#test2 methode dichotomie
print("dichotomie test 2:")
a = -1.0
b = 0.0
epsi = 1e-12
t, nbiter = dichotomie(f, a, b, epsi)
print ('t2 = {0} nbiter = {1}'.format(t, nbiter))

