
def f(x):
	return x**2 - x - 1

def df(x):
	return 2*x - 1

def g(x):
    return 1 + 1/x

from methods import *



print("\n")
si=" Test 1 Secante"
print(si)
print("\n")

#Test 1 secante
print("\n")
si=" Test 1 Secante"
print(si)
print("\n")


x0=1.5
x1=2.0
epsi=1e-2
secante(f,x0,x1,epsi)
print("\n")

#Test 2 secante
print("\n")
sa=" Test 2 Secante"
print(sa)
print("\n")

x0=-1.0
x1=-0.5
secante(f,x0,x1,epsi)
print("\n")




