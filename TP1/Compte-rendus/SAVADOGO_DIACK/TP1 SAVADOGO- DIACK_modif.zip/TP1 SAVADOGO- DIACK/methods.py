def point_fixe(g, x0 ,epsi):
	x = x0 
	nbiter = 0
	delta = 2*epsi
	
	while delta > epsi :
		nbiter += 1
		x1=g(x) 
		delta = abs(x1-x)
		x=x1
		print x
	return x, nbiter



def newton(f, df, x0 ,epsi):
	nbiter = 0
	x = x0 
	delta = 2*epsi
	
	while delta > epsi :
		nbiter += 1
		x1 = x - f(x) / df(x)# c'est cici qu'on remplace g par x - f(x)/df(x)
		delta = abs(x1-x)
		x = x1
		print x
	return x, nbiter




def secante(f,x0,x1,epsi):
	delta=2*epsi
	nbiter=0
	while delta > epsi and nbiter < 100:
		nbiter+=1
		num = x1-x0
		delta = abs(num)
		den = f(x1)-f(x0)
		x2=x1-num/den*f(x1)
		x0=x1
		x1=x2
		print('x = {0},nbiter = {1}\n'.format(x2,cpt))
	return x2





def dichotomie(f, a, b, epsi):
	nbiter = 0
	while b-a > epsi:
		nbiter += 1
		m = (a+b)/2
		if f(a)*f(m)> 0:
			a=m
		else: 
			b=m
	return m, nbiter


