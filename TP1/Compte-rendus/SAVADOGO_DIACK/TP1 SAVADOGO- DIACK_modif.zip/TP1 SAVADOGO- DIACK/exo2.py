def g(x):
    return 1 + 1/x



import matplotlib.pyplot as plt 
import numpy as np
t = np.arange(1.5, 2.0, 0.01)
plt.plot(t, g(t), 'r-', t, t, 'b')
plt.grid('on')
plt.axis('equal')
plt.show()


print("Les 25 premiers termes de la suite")
res=1.0
stock=[]
i=0
print(res)



for i in range (25):
	stock.append(res)
	res=(1+1/res)
	print(res)

print("\n")

