def f(x):
	return x**2 - x - 1

def df(x):
	return 2*x - 1

def g(x):
    return 1 + 1/x

from methods import *



print('test1 methode de newton:')
x0 = 1.0
epsi = 1e-12
t, nbiter = newton(f, df, x0, epsi)
print ('t = {0} et nbiter = {1}'.format(t, nbiter))
print ('g(t)={0}'.format(g(t)))

print("\n")
#test2 methode de newton
print('test2 methode de newton:')
x0 = -1.0
epsi = 1e-12
t2, nbiter = newton(f, df, x0, epsi)
print ('t2 = {0} et nbiter = {1}'.format(t2, nbiter))
print ('g(t2)={0}'.format(g(t2)))

