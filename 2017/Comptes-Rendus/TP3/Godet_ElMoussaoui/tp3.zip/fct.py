def f(x):
    return x**2 - 5

print f(10)

