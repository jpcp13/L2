from tp4 import *

a=(p(200))
print a

