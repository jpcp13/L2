from tp4 import *

n=5
m = is_prime((2**(2**n))+1)
f = (2**(2**n))+1
print m
print f
