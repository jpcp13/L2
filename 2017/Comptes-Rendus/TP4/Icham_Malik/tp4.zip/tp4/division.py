import math
x=522
y=15
R=math.fmod(x,y)
Q=x/y
print Q
print R

