from tp4 import *
#a) voir fichier odt
#b) voir fichier odt

a= factors(4864)
print(a)

b = factors(3458)
print(b)

#c) voir fichier odt
#d) voir fichier odt
#e) voir fichier tp4.py pour la fonction
y = euclide(4864,3458)
print(y)
