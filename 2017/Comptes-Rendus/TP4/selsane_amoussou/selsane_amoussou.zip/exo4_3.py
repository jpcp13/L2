from tp4 import *

#a)voir fichier odt
#b) voir fichier odt
#c) voir fichier tp4.py pour la fonction
p = factors(60)
print(p)
