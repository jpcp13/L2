from tp4 import * 

e=eratosthene(997)
print e


