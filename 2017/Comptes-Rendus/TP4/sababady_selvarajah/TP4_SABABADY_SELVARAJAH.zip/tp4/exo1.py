#SABABADY Kamala
#SELVARAJAH Dinusan

from math import sqrt
from tp4 import *

a = 25
b = 3
print("a/b")
print(a/b)
print(a%b)
print('\n')


for i in range(6):
	f = 2**(2**i) + 1
	p = is_prime(f)
	print(f)
	print(p)
	


