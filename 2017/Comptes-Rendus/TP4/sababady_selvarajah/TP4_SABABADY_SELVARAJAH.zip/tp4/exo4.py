#SABABADY Kamala
#SELVARAJAH Dinusan


from tp4 import *


s = euclide(4864,3458)
print(s)
