#SABABADY Kamala
#SELVARAJAH Dinusan

from tp4 import *


k = factors(924)
print(k)

p = factors1(60)
print(p)
