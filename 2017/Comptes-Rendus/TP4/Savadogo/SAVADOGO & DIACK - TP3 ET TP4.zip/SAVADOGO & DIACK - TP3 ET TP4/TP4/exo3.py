from methods import *
facteur(3458)
print('\n')
