from methods import *
print is_primes(14)
