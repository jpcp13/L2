from methods import *
print primes(1000)  # affiche les nombres premiers entre 2 et 1000
