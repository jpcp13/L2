from methods import *

print euclide(4864, 3458) 
