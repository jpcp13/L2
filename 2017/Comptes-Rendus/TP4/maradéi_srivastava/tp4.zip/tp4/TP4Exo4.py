from fonctions import * 

print(factors(924))