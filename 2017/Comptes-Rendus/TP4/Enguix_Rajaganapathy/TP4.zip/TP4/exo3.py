from module import *

print("Test 1")
p = factors(60)
print(p)
print("\n")

print("Test 2")
p = factors(80)
print(p)
print("\n")

print("Test 3")
p = factors(30)
print(p)
print("\n")
