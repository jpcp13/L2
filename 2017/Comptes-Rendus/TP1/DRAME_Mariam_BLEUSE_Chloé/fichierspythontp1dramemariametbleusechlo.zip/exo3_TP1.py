###Exercice 3###

def g(x):
	y = 1 + 1.0/x
	return y

#Question b

 	#Question i

x0 = 1.6
epsi = 1e-12
r = point_fixe(g, x0, epsi)
print ('la racine vaut approximativement {0}'.format(r))
print g(r)

	#Question ii

x0 = -0.6
epsi = 1e-12
r = point_fixe(g, x0, epsi)
print ('la racine vaut approximativement {0}'.format(r))
print g(r)

