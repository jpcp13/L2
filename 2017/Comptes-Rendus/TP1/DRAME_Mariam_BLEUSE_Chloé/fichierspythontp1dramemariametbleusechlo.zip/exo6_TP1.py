###Exercice 6###

#Question b

	#Question i

a = 1.5
b = 2.0
epsi = 1e-12
r = dichotomie(f, a, b, epsi)
print ('la racine vaut approximativement {0}'.format(r))

	#Question ii

a=-1.0
b=0.0
epsi=1e-12
r=dichotomie(f,a,b,epsi)
print r

