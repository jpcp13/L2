###Exercice 2###

#Question a

def g(x):
	y = 1 + 1.0/x
	return y

#Question b

x=1.0
X=[]
for k in range(0,25):
	X.append(g(x))
	x=g(x)
print X
