###Exercice 4###

def f(x):
	y = x**2-x-1.0
	return y

def df(x):
	y=2*x-1
	return y
#Question d

	#Question i

x0=1.0
epsi=1e-12
r=newton(f,df,x0,epsi)
print r

	#Question ii

x0=-1.0
epsi=1e-12
r=newton(f,df,x0,epsi)
print r
