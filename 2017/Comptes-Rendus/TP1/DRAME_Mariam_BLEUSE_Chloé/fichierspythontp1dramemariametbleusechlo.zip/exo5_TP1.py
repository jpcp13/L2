###Exercice 5###

def f(x):
	y = x**2-x-1.0
	return y

#Question d

	#Question i

x0 = 1.5
x1 = 2.0
epsi = 1e-12
r = secante(f, x0, x1, epsi)
print r

	#Question ii

x0 = -1.0
x1 = -0.5
epsi = 1e-12
r = secante(f, x0, x1, epsi)
print r
