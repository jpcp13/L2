###Exercice 1###

#Question a

def f(x):
	y = x**2-x-1.0
	return y

#Question b

import matplotlib.pyplot as plt
import numpy as np
x = np.arange(-1.0, 2.0, 0.1)
y = f(x)
plt.plot(x, y)
plt.show()


